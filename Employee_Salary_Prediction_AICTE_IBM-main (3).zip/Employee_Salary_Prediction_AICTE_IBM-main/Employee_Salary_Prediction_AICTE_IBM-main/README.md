# 💼Employee_Salary_Prediction_AICTE_IBM 💼
This application performs salary classification by analyzing key factors including an employee's education level, work experience, and working hours.
